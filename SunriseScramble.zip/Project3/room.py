"""
ZACHARY WILLIAMS

SUNRISE SCRAMBLE
This game is a text-based adventure game that follows the player,
Jessie the farmer, who must get the chores done in time for breakfast.

I certify that this code is mine, and mine alone,
in accordance with GVSU academic honesty policy.

11-25-2024
"""
from item import Item
from npc import NPC

class Room:
    """
    This class defines the rooms that the player can move between.
    Rooms may contain up to 1 instance of the NPC class
    and 1 instance of the Item class.
    """
    def __init__(self, desc: str, item: Item = None, npc: NPC = None, name: str = ""):
        self.description: str = desc
        self.item: Item = item
        self.npc: NPC = npc
        self.neighbors: dict = {}
        self.name: str = name

    def get_item(self) -> Item | None:
        """
        :return: The room's item
        """
        return self.item

    def get_npc(self) -> NPC | None:
        """
        :return: The room's NPC
        """
        return self.npc

    def get_description(self) -> str:
        """
        :return: The room's description
        """
        return self.description

    def get_name(self):
        """
        :return: The room's nae
        """
        return self.name

    def set_item(self, item: Item) -> None:
        """
        Sets the item in the room
        :param item: The item to place in the room
        """
        self.item: Item = item

    def set_npc(self, npc: NPC) -> None:
        """
        Sets the NPC inhabiting the room
        :param npc: The NPC to place in the room
        """
        self.npc: NPC = npc

    def set_description(self, desc: str) -> None:
        """
        Sets the room's description
        :param desc: The room's description
        """
        self.description: str = desc

    def has_item(self) -> bool:
        """
        Checks if there is an item in the room
        :return: Boolean, whether there is an item or not
        """
        return True if self.item else False


    def has_npc(self) -> bool:
        """
        Checks if there is an NPC in the room
        :return: Boolean, whether there is an NPC or not
        """
        return True if self.npc else False

    def add_neighbor(self, dir: str, rm):
        """
        Adds to the dictionary of adjacent rooms
        :param dir: The new neighboring room's direction
        :param rm: The new neighboring room
        """
        self.neighbors[dir]: Room = rm

    def get_neighbor(self, dir: str):
        """
        :param dir: Which direction to check for a neighbor
        :return: The neighbor in the chosen direction, if there is one
        """
        if dir in self.neighbors.keys():
            return self.neighbors[dir]
        else:
            return None

    def remove_item(self):
        """
        Removes the room's item and returns it
        :return: The removed item
        """
        item: Item = self.item
        self.item = None
        return item

    def __str__(self):
        """
        :return: The room's description to be displayed to the user,
        as well as the descriptions of its item and NPC if applicable
        """
        room_description = f"You are {self.description}."
        if self.has_item():
            room_description += "\n" + f"You see {self.item}."
        if self.has_npc():
            room_description += "\n" + f"You meet {self.npc.name}."
        return room_description