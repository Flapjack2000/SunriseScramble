"""
ZACHARY WILLIAMS

SUNRISE SCRAMBLE
This game is a text-based adventure game that follows the player,
Jessie the farmer, who must get the chores done in time for breakfast.

I certify that this code is mine, and mine alone,
in accordance with GVSU academic honesty policy.

11-25-2024
"""
from npc import NPC
from item import Item
from room import Room

class Game:
    def __init__(self):
        self.create_world()
        self.inventory: list[Item] = []
        self.message: str = ""
        self.current_room: Room = self.kitchen
        self.previous_room: Room | None = None
        self.has_retreated: bool = False

        self.are_chores_done: bool = False
        self.is_breakfast_made: bool = False
        self.chore_list = {
            1:["Milk the cow", False],
            2:["Pick vegetables from the garden", False],
            3:["Collect eggs from the chicken coop", False],
            4:["Put firewood in the woodstove", False],
            5:["Put away the laundry", False],
            6:["Get the mail", False],
            7:["Set the table for breakfast", False],
            8:["Wake up Skylar", False],
        }

    def update_chore_list(self) -> None:
        """
        Checks which chores have been completed and removes them from the chore list
        Also adds chores back if they are undone
        """
        # Milk the cow - milk in inventory
        self.chore_list[1][1]: bool = True if self.milk in self.inventory else False

        # Pick vegetables from the garden - vegetables in inventory
        self.chore_list[2][1]: bool = True if self.vegetables in self.inventory else False

        # Collect eggs from the chicken coop - eggs in inventory
        self.chore_list[3][1]: bool = True if self.eggs in self.inventory else False

        # Put firewood in the woodstove - woodstove item == firewood
        self.chore_list[4][1]: bool = True if self.woodstove.get_item() == self.firewood else False

        # Put away the laundry - bedroom item == clothes
        self.chore_list[5][1]: bool = True if self.bedroom.get_item() == self.clothes else False

        # Get the mail - mail in inventory
        self.chore_list[6][1]: bool = True if self.mail in self.inventory else False

        # Set the table - dining room item == tableware
        self.chore_list[7][1]: bool = True if self.dining_room.get_item() == self.tableware else False

        # Wake up Skylar - Skylar has been spoken to
        self.chore_list[8][1]: bool = True if self.skylar.is_awake else False

        # Check if all done with chores
        if all([chore[1] for chore in self.chore_list.values()]):
            self.are_chores_done: bool = True

    def show_chore_list(self) -> None:
        """
        Shows the list of remaining chores that need to be completed,
        nicely formatted
        """
        chore_text: str = ""
        for key in self.chore_list:
            if not self.chore_list[key][1]:
                chore_text += f"{key}. {self.chore_list[key][0]} \n"
        self.message: str = chore_text

    def chores(self) -> None:
        """
        Simply checks which chores are done and shows the list of chores
        yet to be done to the player.
        Meant to be called as an action by the player.
        """
        self.update_chore_list()
        self.show_chore_list()

    def breakfast(self) -> None:
        """
        The player cooks breakfast in the kitchen.
        Sets final win condition to True, thereby ending the game.
        """
        if self.are_chores_done and self.get_current_room() == self.kitchen:
            # Win condition = True, game over
            self.is_breakfast_made: bool = True
            self.message: str = "You've finished your chores and breakfast is made. Have a great day!"
        elif self.are_chores_done and self.get_current_room() is not self.kitchen:
            # The player must be in the kitchen to cook breakfast
            self.message: str = "Your chores are done, but you can't make breakfast here! Get to the kitchen!"
        else:
            # The player has to do their chores first
            self.message: str = "You need to finish your chores before you start cooking."

    def game_over(self) -> bool:
        # Check that the chores are done and breakfast is made
        if self.are_chores_done and self.is_breakfast_made:
            return True
        else:
            return False

    def quit(self) -> None:
        """
        Exit the program
        """
        exit()

    def pet(self) -> None:
        """
        The player pets the animal NPC if there is one in the area.
        """
        # Check for NPC
        if self.get_current_room().get_npc():
            # Check that the NPC is an animal
            if self.get_current_room().get_npc().is_animal:
                self.message = f"You pet {self.get_current_room().get_npc().get_name()}."
            else:
                self.message = "There are no animals here."
        else:
            self.message = "There are no animals here."

    def get_message(self) -> str:
        """
        :return: The current game message to display to the player
        """
        return self.message

    def get_current_room(self) -> Room:
        """
        :return: The current room that the player is in
        """
        return self.current_room

    def move(self, direction) -> None:
        """
        Try to move to a new room if possible
        """
        next_room = self.get_current_room().get_neighbor(direction)
        if not next_room:
            self.message: str = "You can't move in that direction."
        else:
            self.previous_room: Room = self.get_current_room()
            self.current_room: Room = next_room
            self.message = self.get_current_room().__str__()
            self.has_retreated: bool = False

    def set_welcome_message(self) -> None:
        """
        Set the opening welcome message at the start of the game
        """
        self.message: str = \
            "Welcome to Sunrise Scramble, a text-based role playing video game.\n" + \
            "Wake up! It's time to get the chores done and make breakfast!\n" + \
            "Enter 'chores' to see the list! If you need help, enter 'help'!\n"

    def create_world(self):
        """
        Initializes the items, rooms, and characters of the game world,
        as well as the player's actions and the mechanics
        """

        # Initialize Items
        self.barrel: Item = Item(
            name="barrel",
            desc="a large French oak wine barrel",
            weight=50)
        self.spade: Item = Item(
            name="spade",
            desc="a steel spade made for gardening",
            weight=2)
        self.milk: Item = Item(
            name="milk",
            desc="fresh cow's milk",
            weight=2)
        self.vegetables: Item = Item(
            name="vegetables",
            desc="fresh garden veggies",
            weight=1,
            item_req="spade")
        self.eggs: Item = Item(
            name="eggs",
            desc="a few chicken eggs",
            weight=1)
        self.tableware: Item = Item(
            name="tableware",
            desc="plates, bowls, cups, and silverware",
            weight=3)
        self.clothes: Item = Item(
            name="clothes",
            desc="freshly laundered clothing",
            weight=1)
        self.axe: Item = Item(
            name="axe",
            desc="your trusty ol' axe",
            weight=4)
        self.firewood: Item = Item(
            name="firewood",
            desc="a hefty stack of firewood",
            weight=8,
            item_req="axe")
        self.mail: Item = Item(
            name="mail",
            desc="some junk mail, a magazine, and a coupon",
            weight=1)

        # Initialize NPCs
        self.skylar: NPC = NPC(
            name="Skylar",
            phrase="Zzzzz... snnnnore... zzzzz... Huh? What time is it? Can I have five more minutes?",
            is_awake=False)
        self.charlie: NPC = NPC(
            name="Charlie the horse",
            phrase="Neigh... neigh...",
            is_animal=True)
        self.tripp: NPC = NPC(
            name="Tripp the dog",
            phrase="Ruff! Ruff!",
            is_animal=True)
        self.gladys: NPC = NPC(
            name="Gladys the hen",
            phrase="Bawwwwwk... bawkbawkbawk... bawwwwwk!",
            is_animal=True)

        # Initialize Rooms
        self.kitchen: Room = Room(
            name="kitchen",
            desc="in a well stocked kitchen with an island counter",
            item=self.tableware)
        self.dining_room: Room = Room(
            name="dining room",
            desc="in the dining room")
        self.cellar: Room = Room(
            name="cellar",
            desc="in a dark cellar with canned vegetables and a few barrels",
            item=self.barrel)
        self.bedroom: Room = Room(
            name="bedroom",
            desc="in Skylar's bedroom. On the bed lies a quilt made by your grandmother",
            npc=self.skylar)
        self.laundry_room: Room = Room(
            name="laundry room",
            desc="in the laundry room. The new washer seems to be running nicely",
            item=self.clothes)
        self.porch: Room = Room(
            name="porch",
            desc="out on the front porch. It's a nice view",
            item=self.axe,
            npc=self.tripp)
        self.mailbox: Room = Room(
            name = "mailbox",
            desc="at the mailbox. Your address is painted on the side",
            item=self.mail)
        self.woodstove: Room = Room(
            name="woodstove",
            desc="at the woodstove, which provides heat for the house")
        self.barn: Room = Room(
            name="barn",
            desc="in the barn, where the cow and the horse reside",
            item=self.milk,
            npc=self.charlie)
        self.chicken_coop: Room = Room(
            name="chicken coop",
            desc="at the chicken coop. The chickens glare at you balefully",
            item=self.eggs,
            npc=self.gladys)
        self.garden: Room = Room(
            name="garden",
            desc="in the bountiful garden, full of tomatoes, potatoes, and other vegetables",
            item=self.vegetables)
        self.shed: Room = Room(
            name="shed",
            desc="at the tool shed, near the garden",
            item=self.spade)
        self.forest: Room = Room(
            name="forest",
            desc="in the woods at the north end of the farmstead",
            item=self.firewood)

        # Kitchen Neighbors:
        self.kitchen.add_neighbor("north", self.laundry_room)
        self.kitchen.add_neighbor("west", self.dining_room)
        self.kitchen.add_neighbor("outside", self.porch)

        # Dining Room Neighbors:
        self.dining_room.add_neighbor("north", self.bedroom)
        self.dining_room.add_neighbor("east", self.kitchen)
        self.dining_room.add_neighbor("downstairs", self.cellar)

        # Cellar Neighbors:
        self.cellar.add_neighbor("upstairs", self.dining_room)

        # Bedroom Neighbors:
        self.bedroom.add_neighbor("south", self.dining_room)
        self.bedroom.add_neighbor("east", self.laundry_room)

        # Laundry Room Neighbors:
        self.laundry_room.add_neighbor("south", self.kitchen)
        self.laundry_room.add_neighbor("west", self.bedroom)

        # Porch Neighbors:
        self.porch.add_neighbor("north", self.garden)
        self.porch.add_neighbor("south", self.woodstove)
        self.porch.add_neighbor("east", self.mailbox)
        self.porch.add_neighbor("inside", self.kitchen)

        # Mailbox Neighbors:
        self.mailbox.add_neighbor("west", self.porch)

        # Woodstove Neighbors
        self.woodstove.add_neighbor("north", self.porch)
        self.woodstove.add_neighbor("south", self.chicken_coop)
        self.woodstove.add_neighbor("west", self.barn)

        # Barn Neighbors:
        self.barn.add_neighbor("east", self.woodstove)

        # Chicken Coop Neighbors:
        self.chicken_coop.add_neighbor("north", self.woodstove)

        # Garden Neighbors:
        self.garden.add_neighbor("north", self.forest)
        self.garden.add_neighbor("south", self.porch)
        self.garden.add_neighbor("west", self.shed)

        # Shed Neighbors:
        self.shed.add_neighbor("east", self.garden)

        # Forest Neighbors:
        self.forest.add_neighbor("south", self.garden)

        self.room_hints: dict = {
            "kitchen": "Once your chores are done you can cook breakfast in the kitchen.",
            "dining room": "The tableware is kept in the kitchen.",
            "cellar": "It doesn't seem like there's anything you need to do down here.",
            "bedroom": "It seems like Skylar is still sleeping.",
            "laundry room": "It looks like the dryer is done.",
            "porch": "From here you can see the whole farmstead.\n"
                        "The garden, shed, and forest are to the north.\n",
                        "The barn, chicken coop, and woodstove are to the south."
            "mailbox": "Looks like the mailman came today.",
            "woodstove": "Looks like the fire is dwindling.",
            "barn": "The barn is the home for many of your animals.",
            "chicken coop": "It seems like the hens laid a few eggs this morning.",
            "garden": "Looks like your tomatoes and potatoes are ready to be picked.",
            "shed": "This is where you keep your gardening supplies.",
            "forest": "There are a few big logs that need to be chopped up yet."
        }

        self.actions: dict = {
            "help" : "get hints and suggestions",
            "look": "see the area's description",
            "move *direction*" : "move to another area",
            "retreat" : "move back to the previous area",
            "paths" : "see the directions in which you can travel",
            "take" : "takes the item from the area you are in",
            "place *item*" : "deposit an item into the area",
            "speak" : "hear what other characters have to say",
            "items" : "view your inventory",
            "pet" : "pet an animal",
            "chores" : "check your chore list",
            "breakfast" : "make breakfast (once your chores are done)",
            "quit" : "exit the game"
        }

    def look(self) -> None:
        """
        Set the game message to the current room's description
        """
        self.message: str = self.current_room.__str__()

    def help(self) -> None:
        """
        Provides hints and suggestions
        """
        room_name: str = self.current_room.get_name()
        self.message: str = "Complete all of the chores and make breakfast to win. "

        # Room specific hint/text
        self.message += f"\n{self.room_hints[room_name]}"

        # Show player actions
        self.message += "\nActions:"
        for action in self.actions:
            self.message += f"\n\t{action} - {self.actions[action]}"

    def paths(self) -> None:
        """
        Show adjacent rooms
        """
        room_name: str = self.get_current_room().get_name()
        nbors: dict = self.get_current_room().neighbors
        self.message = f"Current location: {room_name}. Adjacent areas:"
        for dir in nbors:
            self.message += f"\n\t-{dir} to {nbors[dir].name}"

    def items(self) -> None:
        """
        Displays the player's inventory
        """

        # Check if the inventory is empty
        if len(self.inventory) == 0:
            self.message: str = "You aren't holding anything."

        # Loop through and display each item in the inventory
        else:
            message: str = "You are holding:"
            for item in self.inventory:
                message += f"\n\t- {item.get_name()}"
            self.message: str = message

    def take(self) -> None:
        """
        Takes the item from the current room and adds it to the inventory if:
        - the item's weight < 50
        - its required item (if it has one) is in the inventory
        """

        # Check that the room actually contains an item
        if self.get_current_room().has_item():
            # Find what that item's requirement's name is
            item_req: str = self.get_current_room().get_item().item_req

            # Can't pick it up if it's heavier than 50 units of weight
            if self.get_current_room().get_item().weight >= 50:
                self.message: str = "The item here is too heavy to pick up."

            # If the requirement is met or there is no requirement
            elif (self.search_items(item_req)) or (item_req is None):
                # Display pick up message
                self.message: str = f"You are holding {self.get_current_room().get_item()}."

                # Add the item to the inventory and simultaneously remove it from the room
                self.inventory.append(self.get_current_room().remove_item())

            # If the player is missing the required item
            elif not self.search_items(item_req):
                self.message: str = f"You need the {item_req} to take this item."

        else:
            # Let the player know there is nothing here
            self.message: str = "There is nothing here to take."

    def place(self, name) -> None:
        """
        Places an item into the current room if:
        - the player has that item
        - the room doesn't already contain an item
        :param name: The name of the item to be placed
        """
        # Check that the player has the item they are trying to place
        if self.search_items(name):
            # Check that the room doesn't have an item already
            if not self.current_room.has_item():
                item: Item = self.search_items(name)

                # Place the item into the room
                self.get_current_room().set_item(item)

                # Tell the player they placed the item
                self.message: str = f"You set down {item} in the {self.get_current_room().get_name()}."

                # Remove the item from inventory
                self.inventory.remove(item)

            else:
                # Let the player know there is an item here already
                self.message: str = f"This area already has an item: {self.get_current_room().get_item()}."
        else:
            # Let the player know they don't have the item they tried to place
            self.message: str = "You are not holding that item."


    def search_items(self, name) -> Item | None:
        """
        Searches through the player's inventory for an item
        :param name: The name of the item to look for
        :return: The item if it's in the player's inventory
        """
        # Loop over the inventory to find the item
        for item in self.inventory:
            if item.name == name:
                return item
        return None

    def parse_command(self) -> tuple[str,str]:
        """
        Receives commands from the player
        :return: Commands
        """
        words: list = input("Enter>>> ").split()
        # Check that the player actually entered something
        while len(words) == 0:
            words: list = input("Enter>>> ").split()

        first: str = words[0].lower()
        if len(words) > 1:
            second: str = words[1].lower()
        else:
            second: None = None
        return first, second

    def speak(self) -> None:
        """
        The phrase of the NPC in the room (if there is one) is displayed
        """
        # Check that the room has an NPC
        if self.get_current_room().has_npc():
            # Display the NPC's phrase
            self.message: str = self.get_current_room().get_npc().speak()

            # Wake up the NPC if they are sleeping
            # Only important for completing the "Wake up Skylar" chore.
            # It proves that the player spoke to Skylar
            self.get_current_room().get_npc().is_awake = True
        else:
            # Tell the player no one is there to speak
            self.message: str = "There is no one else here."

    def retreat(self) -> None:
        """
        Attempt to move to the previous room
        """
        # Check that there is a previous room, i.e. the player has moved
        # from the starting location, and that they have not already retreated
        if (not self.has_retreated) and (self.previous_room is not None):
            # swap the previous and current rooms
            self.current_room, self.previous_room = self.previous_room, self.current_room

            # The player has now retreated, and they cannot retreat again before moving
            # This will be reset to False when the player moves successfully
            self.has_retreated: bool = True

            # Let the player know they moved back
            self.message = "You retreated. \n" + str(self.current_room)
        else:
            self.message = "You cannot retreat from here."

    def play(self) -> None:
        """
        Runs the game
        """
        # Print initial welcome message
        self.set_welcome_message()
        print(self.get_message())

        # Loop until the game is over
        while True:
            # Get command from player
            first, second = self.parse_command()

            # Decipher command
            if first == "move":
                self.move(second)
            elif first == "look":
                self.look()
            elif first == "speak":
                self.speak()
            elif first == "pet":
                self.pet()
            elif first == "take":
                self.take()
            elif first == "place":
                self.place(second)
            elif first == "help":
                self.help()
            elif first == "items":
                self.items()
            elif first == "retreat":
                self.retreat()
            elif first == "paths":
                self.paths()
            elif first == "chores":
                self.chores()
            elif first == "breakfast":
                self.breakfast()
            elif first == "quit":
                self.quit()
            else:
                self.message: str = "Invalid command. Please try again."

            # Display game message
            print(self.get_message())

            # Check if the game is over
            if self.game_over():
                self.quit()

    def auto_win(self) -> None:
        print(self.get_message())
        self.chores()
        print(self.get_message())
        self.take()
        print(self.get_message())
        self.move("west")
        print(self.get_message())
        self.place("tableware")
        print(self.get_message())
        self.chores()
        print(self.get_message())
        self.move("north")
        print(self.get_message())
        self.speak()
        print(self.get_message())
        self.chores()
        print(self.get_message())
        self.move("east")
        print(self.get_message())
        self.take()
        print(self.get_message())
        self.retreat()
        print(self.get_message())
        self.place("clothes")
        print(self.get_message())
        self.chores()
        print(self.get_message())
        self.move("east")
        print(self.get_message())
        self.move("south")
        print(self.get_message())
        self.move("outside")
        print(self.get_message())
        self.take()
        print(self.get_message())
        self.move("east")
        print(self.get_message())
        self.take()
        print(self.get_message())
        self.chores()
        print(self.get_message())
        self.retreat()
        print(self.get_message())
        self.move("north")
        print(self.get_message())
        self.move("west")
        print(self.get_message())
        self.take()
        print(self.get_message())
        self.retreat()
        print(self.get_message())
        self.take()
        print(self.get_message())
        self.chores()
        print(self.get_message())
        self.move("north")
        print(self.get_message())
        self.take()
        print(self.get_message())
        self.move("south")
        print(self.get_message())
        self.move("south")
        print(self.get_message())
        self.move("south")
        print(self.get_message())
        self.place("firewood")
        print(self.get_message())
        self.chores()
        print(self.get_message())
        self.move("south")
        print(self.get_message())
        self.take()
        print(self.get_message())
        self.chores()
        print(self.get_message())
        self.pet()
        print(self.get_message())
        self.move("north")
        print(self.get_message())
        self.move("west")
        print(self.get_message())
        self.take()
        print(self.get_message())
        self.chores()
        print(self.get_message())
        self.move("east")
        print(self.get_message())
        self.move("north")
        print(self.get_message())
        self.move("inside")
        print(self.get_message())
        self.breakfast()
        print(self.get_message())

if __name__ == '__main__':
    g = Game()
    g.play()