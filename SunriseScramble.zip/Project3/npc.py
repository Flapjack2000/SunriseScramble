"""
ZACHARY WILLIAMS

SUNRISE SCRAMBLE
This game is a text-based adventure game that follows the player,
Jessie the farmer, who must get the chores done in time for breakfast.

I certify that this code is mine, and mine alone,
in accordance with GVSU academic honesty policy.

11-25-2024
"""
class NPC:
    """
    This class defines the NPCs, or Non-Player Characters
    within the game world. NPCs inhabit Rooms, and only one NPC can
    exist within an instance of the class.
    """
    def __init__(self, name: str, phrase: str, is_animal: bool = False, is_awake: bool = True):
        self.name: str = name
        self.phrase: str = phrase
        self.is_animal: bool = is_animal
        self.is_awake: bool = is_awake

    def get_name(self) -> str:
        """
        :return: The name of the NPC
        """
        return self.name

    def get_phrase(self) -> str:
        """
        :return: the phrase of the NPC
        """
        return self.phrase

    def set_name(self, name) -> None:
        """
        Sets the name of the NPC
        :param name: The name of the NPC
        """
        self.name: str = name

    def set_phrase(self, phrase) -> None:
        """
        Sets the phrase of the NPC
        :param phrase: the phrase of the NPC
        """
        self.phrase: str = phrase

    def speak(self) -> str:
        """
        :return: The formatted output of the NPC's spoken phrase
        """
        return f'{self.name} says, "{self.phrase}"'