"""
ZACHARY WILLIAMS

SUNRISE SCRAMBLE
This game is a text-based adventure game that follows the player,
Jessie the farmer, who must get the chores done in time for breakfast.

I certify that this code is mine, and mine alone,
in accordance with GVSU academic honesty policy.

11-25-2024
"""
class Item:
    def __init__(self, name: str, desc: str, weight: int, item_req: str | None = None):
        self.name: str = name
        self.description: str = desc
        self.weight: int = weight

        # The name of the item that the player must have
        # in order to take the item
        self.item_req: str = item_req

    def __str__(self) -> str:
        """
        :return: The item's description
        """
        return self.description

    def get_name(self) -> str:
        """
        :return: The item's name
        """
        return self.name

    def get_description(self) -> str:
        """
        :return: The item's description
        """
        return self.description

    def get_weight(self) -> int:
        """
        :return: The item's weight
        """
        return self.weight

    def set_name(self, name) -> None:
        """
        Sets the item's name
        :param name: The name of the item
        """
        self.name: str = name

    def set_weight(self, wt) -> None:
        """
        Sets the item's weight
        :param wt: The weight of the item
        """
        self.weight: int = wt

    def set_description(self, desc) -> None:
        """
        Sets the item's description
        :param desc: The description of the item
        """
        self.description: str = desc